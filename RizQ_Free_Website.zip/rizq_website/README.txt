RizQ Website — Free starter

1. Extract rizq_website.zip.
2. Open index.html in a browser to preview.
3. To publish free: create a GitHub repository named USERNAME.github.io (replace USERNAME with your GitHub username), upload index.html, and enable GitHub Pages if prompted.
4. Product/settings changes are saved in the same browser on the same device (localStorage). This starter does NOT include a shared cloud database or server-side order storage.
5. Website orders open RizQ Messenger. The customer details/order summary are prepared for copying into Messenger. WhatsApp can be enabled later in Admin Settings after adding a number.

Brand: RizQ
Palette: Navy #0F2235, Cream #F5F1EB, Beige #E8E0D5, Gold #C9B896
Messenger: https://m.me/61596219210720
